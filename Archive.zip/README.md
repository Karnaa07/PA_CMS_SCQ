# projet_annuel


### Prerequisites

...

## Accéder à une page 
```
localhost/lenomdelapage.sonextension

exemple : localhost/index.php
```
## Accéder à PhpMyAdmin
http://localhost:8888/

## Start-up

...

## Made with

...

## Versions

**version:** 1.0

## Author
* **YVARS Clement** _alias_ [@clement-Yvars](https://github.com/clement-Yvars)
* **Yalicheff Sebastien** _alias_ [@syalicheff](https://github.com/syalicheff)
* **Girard Quentin** _alias_ [@Karnaa07](https://github.com/Karnaa07)
