<?php

namespace App\User;

class Security
{

    public function __construct()
    {
        echo "Constructeur de security user";
    }


}