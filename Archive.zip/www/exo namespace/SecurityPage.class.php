<?php

namespace App\Page;

class Security
{

    public function __construct()
    {
        echo "Constructeur de security page";
    }

}