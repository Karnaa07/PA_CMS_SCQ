<?php

define("DBUSER", "root");
define("DBPWD", "password");
define("DBHOST", "database");
define("DBNAME", "waterlily");
define("DBPORT", "3306");
define("DBDRIVER", "mysql");
define("DBPREFIXE", "waterlily_");

